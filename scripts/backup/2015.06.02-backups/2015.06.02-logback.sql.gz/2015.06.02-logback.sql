-- MySQL dump 10.13  Distrib 5.5.43, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: logbook
-- ------------------------------------------------------
-- Server version	5.5.43-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `logbook`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `logbook` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `logbook`;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `name_id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `email2` varchar(40) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `phone2` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`name_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_analysis`
--

DROP TABLE IF EXISTS `posts_analysis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_analysis` (
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(25) DEFAULT NULL,
  `message` text,
  `crossout` tinyint(1) NOT NULL DEFAULT '0',
  `post_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `filenames` text,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_analysis`
--

LOCK TABLES `posts_analysis` WRITE;
/*!40000 ALTER TABLE `posts_analysis` DISABLE KEYS */;
INSERT INTO `posts_analysis` VALUES ('2015-05-27 07:09:25','Testing.','Test.',0,1,NULL),('2015-05-26 18:55:39','Test','Test Post Picture<i><br>**This timestamp was manually entered**</i>',0,2,'a:1:{i:0;s:7:\"dad.jpg\";}'),('2015-05-27 18:57:34','Test','Test<i><br>**This timestamp was manually entered**</i>',0,3,'a:1:{i:0;s:7:\"dad.jpg\";}'),('2015-06-27 18:58:08','fdsfadf','fsdfasdaf<i><br>**This timestamp was manually entered**</i>',0,4,'a:1:{i:0;s:7:\"dad.jpg\";}'),('2015-05-27 18:58:47','fdfsafdsa','fds',0,5,'a:1:{i:0;s:7:\"dad.jpg\";}'),('2015-05-27 18:58:48','fdfsafdsa','fds',0,6,'a:1:{i:0;s:7:\"dad.jpg\";}'),('2015-05-27 18:59:58','fdsafdsa','fsdafsdfa',0,7,'a:1:{i:0;s:7:\"dad.jpg\";}'),('2015-05-28 17:31:10','Test','Test',0,8,NULL),('2005-05-24 18:10:38','fdsa','fdsa<i><br>**This timestamp was manually entered**</i>',0,9,NULL),('2015-05-27 18:10:59','fdsa','fdsa<i><br>**This timestamp was manually entered**</i>',0,10,NULL),('2015-05-28 18:11:19','fdsa','fdsa<i><br>**This timestamp was manually entered**</i>',0,11,NULL),('2015-05-28 18:15:18','fdsafdsafd','fdsafsdfd',1,12,NULL),('2015-05-28 18:15:37','fdsfda','fdsafdsa',0,13,NULL),('2015-05-28 18:24:44','fdsa','fdsa<i><br>**This timestamp was manually entered on 2015-05-28**</i>',0,14,NULL),('2015-05-28 18:25:33','fdsa','fdsa<i><br>**This timestamp was manually entered on 1432837533 2015-05-28**</i>',0,15,NULL),('2015-05-28 18:32:11','fdsa','fdsa<i><br>**This timestamp was manually entered on 1432837931, 2015-05-28**</i>',0,16,NULL),('2015-05-28 18:32:34','fdsa','fdsa<i><br>**This timestamp was manually entered on 1432837954, 2015-05-28**</i>',0,17,NULL),('2015-05-28 18:34:23','fda','fdsa<i><br>**This timestamp was manually entered on 02:34:23, 2015-05-28**</i>',0,18,NULL),('2015-05-28 18:34:46','fdsa','fdsa<i><br>**This timestamp was manually entered on 14:34:46, 2015-05-28**</i>',0,19,NULL),('2015-05-28 18:38:45','fdsa','fdsa<i><br>**This timestamp was manually entered on 14:38:45, 2015-05-28**</i>',0,20,NULL),('2015-05-28 18:39:45','fdsa','fdsafdsa<i><br>**This timestamp was manually entered on 14:39:45, 2015-05-28**</i>',0,21,NULL),('2015-05-28 18:40:26','fdsa','fdsafdsa<i><br>**This timestamp was manually entered on 14:40:26, 2015-05-28**</i>',0,22,NULL),('2015-05-28 18:40:51','fdsa','fdsafdsa<i><br>**This timestamp was manually entered on 14:40:51, 2015-05-28**</i>',0,23,NULL),('2015-05-28 18:41:13','fdsa','fdsafdsa<i><br>**This timestamp was manually entered on 14:41:13, 2015-05-28**</i>',0,24,NULL),('2015-05-28 18:46:56','fdas','fdsafd<i><br>**This timestamp was manually entered on 14:46:56, 2015-05-28**</i>',0,25,NULL),('2015-10-15 19:11:54','fdsfds','faasdf<i><br>**This timestamp was manually entered on 15:11:54, 2015-05-28**</i>',0,26,NULL),('2015-10-15 19:14:25','2015','fdsfda<i><br>**This timestamp was manually entered on 15:14:25, 2015-05-28**</i>',0,27,NULL),('0000-00-00 00:00:00','test','test<i><br>**This timestamp was manually entered on 15:15:04, 2015-05-28**</i>',0,28,NULL),('2015-01-01 20:15:29','testestest','etsetstetsets<i><br>**This timestamp was manually entered on 15:15:29, 2015-05-28**</i>',0,29,NULL),('1989-01-01 20:15:43','fdsa','fdsa<i><br>**This timestamp was manually entered on 15:15:43, 2015-05-28**</i>',0,30,NULL),('2015-01-01 20:22:43','test','Testfdsafdsafafd<i><br>**This timestamp was manually entered on 15:22:43, 2015-05-28**</i>',0,31,NULL),('2015-01-01 20:24:24','fdsa','fdsafdsafsda<i><br>**This timestamp was manually entered on 15:24:24, 2015-05-28**</i>',0,32,'a:0:{}'),('2015-05-28 19:24:52','dada','dadfa<i><br>**This timestamp was manually entered on 15:24:52, 2015-05-28**</i>',0,33,'a:2:{i:0;s:12:\"LostBets.jpg\";i:1;s:16:\"Eve-WhatToDo.jpg\";}'),('2010-01-01 20:25:14','des','desss<i><br>**This timestamp was manually entered on 15:25:14, 2015-05-28**</i>',0,34,'a:2:{i:0;s:39:\"Screenshot from 2014-10-06 08:11:15.png\";i:1;s:21:\"TranscriptRequest.jpg\";}'),('2005-01-25 20:32:49','fsdafdsaf','dsafdafd<i><br>**This timestamp was manually entered on 15:32:49, 2015-05-28**</i>',0,35,'a:3:{i:0;s:12:\"Brothers.jpg\";i:1;s:18:\"FuckYouComcast.jpg\";i:2;s:39:\"Screenshot from 2014-09-16 21:23:47.png\";}'),('2015-05-29 02:35:41','fdsfsdaf','fdsafdsafdf',0,36,NULL),('2015-05-29 02:46:10','fdsafdsaf','fdsafdsafd',0,37,NULL),('2015-01-02 03:46:27','fdsafd','fdsafdads<i><br>**This timestamp was manually entered on 22:46:27, 2015-05-28**</i>',0,38,NULL),('2015-06-01 01:23:03','whitespace','whitespace testing<br />\r\nwhitespace testing<br />\r\n<br />\r\n<br />\r\n<br />\r\nwhite space testingwhitespace testing<br />\r\nwhitespace testing<br />\r\n<br />\r\n<br />\r\n<br />\r\nwhite space testingwhitespace testing<br />\r\nwhitespace testing<br />\r\n<br />\r\n<br />\r\n<br />\r\nwhite space testingwhitespace testing<br />\r\nwhitespace testing<br />\r\n<br />\r\n<br />\r\n<br />\r\nwhite space testingwhitespace testing<br />\r\nwhitespace testing<br />\r\n<br />\r\n<br />\r\n<br />\r\nwhite space testing',0,39,'a:6:{i:0;s:21:\"CC_Z_Distribution.jpg\";i:1;s:21:\"CC_Y_Distribution.jpg\";i:2;s:21:\"N_Charge_Clusters.jpg\";i:3;s:18:\"PCD_Sum_energy.jpg\";i:4;s:20:\"N_Scint_Clusters.jpg\";i:5;s:27:\"Sum_Raw_Energy_Clusters.jpg\";}'),('2015-06-02 06:32:35','twest','Twesting<i><br>**This timestamp was manually entered on 2015-06-02, 02:32:35**</i>',0,40,NULL);
/*!40000 ALTER TABLE `posts_analysis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_borexino`
--

DROP TABLE IF EXISTS `posts_borexino`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_borexino` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `username` varchar(25) DEFAULT NULL,
  `message` text,
  `crossout` tinyint(1) NOT NULL DEFAULT '0',
  `post_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `filenames` text,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_borexino`
--

LOCK TABLES `posts_borexino` WRITE;
/*!40000 ALTER TABLE `posts_borexino` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_borexino` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_darkside`
--

DROP TABLE IF EXISTS `posts_darkside`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_darkside` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `username` varchar(25) DEFAULT NULL,
  `message` text,
  `crossout` tinyint(1) NOT NULL DEFAULT '0',
  `post_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `filenames` text,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_darkside`
--

LOCK TABLES `posts_darkside` WRITE;
/*!40000 ALTER TABLE `posts_darkside` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_darkside` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_lxe`
--

DROP TABLE IF EXISTS `posts_lxe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_lxe` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `username` varchar(25) DEFAULT NULL,
  `message` text,
  `crossout` tinyint(1) NOT NULL DEFAULT '0',
  `post_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `filenames` text,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_lxe`
--

LOCK TABLES `posts_lxe` WRITE;
/*!40000 ALTER TABLE `posts_lxe` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_lxe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_misc`
--

DROP TABLE IF EXISTS `posts_misc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_misc` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `username` varchar(25) DEFAULT NULL,
  `message` text,
  `crossout` tinyint(1) NOT NULL DEFAULT '0',
  `post_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `filenames` text,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_misc`
--

LOCK TABLES `posts_misc` WRITE;
/*!40000 ALTER TABLE `posts_misc` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_misc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_photosensor`
--

DROP TABLE IF EXISTS `posts_photosensor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_photosensor` (
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `username` varchar(25) DEFAULT NULL,
  `message` text,
  `crossout` tinyint(1) NOT NULL DEFAULT '0',
  `post_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `filenames` text,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_photosensor`
--

LOCK TABLES `posts_photosensor` WRITE;
/*!40000 ALTER TABLE `posts_photosensor` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_photosensor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-06-02 16:31:52
